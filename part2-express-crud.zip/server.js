var express = require("express");
var bp = require("body-parser");
var mongo = require("mongojs");

var db = mongo("ibmdb",["heroes"]);
var app = express();

// Middleware
app.use(express.static(__dirname+"/public"));
app.use(express.static(__dirname+"/public/lib/"));
app.use(bp.json());

/*
app.get("/", function(req, res){
	res.send();
});
 */

app.get("/heroes", function(req, res){
	db.heroes.find(function(error, documents){
		res.send(documents);
	});
});
app.post("/heroes", function(req, res){
	// console.log(req.body);
	db.heroes.insert(req.body, function(error, document){
		if(error){
			console.log(error);
		}else{
			res.json(document);
		}
	})
});

/*
CRUD

C post
R get
U update / put
D delete

app.update
app.delete
*/

app.listen(9900);
console.log("server is now running on port 9900");