var express = require("express");
var bodyParser = require("body-parser");

var app = express();
var heros = ["batman","ironman","superman","phantom"];
app.use( bodyParser({extended : false}) );

app.get("/", function(req,res){
		// res.send("hello there");
		res.render("home-step6.pug", {
			pageTitle : "Welcome to IBM Bangalore",
			heros : heros
		});
	});

app.post("/", function(req,res){
		console.log(req.body.heroName);
		heros.push(req.body.heroName);
		res.redirect("/");
		req.end();
	});

app.get("*", function(req,res){
		res.send("your page is not found");
	});

var server = app.listen(3366, function(){
	console.log("server is now running on 3366");
});
